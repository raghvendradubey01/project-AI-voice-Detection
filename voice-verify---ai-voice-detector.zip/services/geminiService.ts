
import { GoogleGenAI, Type } from "@google/genai";
import { DetectionResponse, Language } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const analyzeVoice = async (
  base64Audio: string,
  language: Language,
  mimeType: string = 'audio/mp3'
): Promise<DetectionResponse> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: [
        {
          parts: [
            {
              inlineData: {
                mimeType: mimeType,
                data: base64Audio
              }
            },
            {
              text: `Analyze this audio sample in ${language}. 
              Determine if the voice is AI_GENERATED (synthetic, cloned, or TTS) or HUMAN (real person recording).
              
              Look for:
              1. Unnatural pitch consistency or robotic patterns.
              2. Spectral artifacts or phase issues typical of neural vocoders.
              3. Micro-hesitations or breathing patterns (Human indicators).
              4. Prosody and emotional variance.
              
              Provide a detailed classification with confidence score and explanation.`
            }
          ]
        }
      ],
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            status: { type: Type.STRING },
            language: { type: Type.STRING },
            classification: { type: Type.STRING, enum: ['AI_GENERATED', 'HUMAN'] },
            confidenceScore: { type: Type.NUMBER },
            explanation: { type: Type.STRING }
          },
          required: ["status", "language", "classification", "confidenceScore", "explanation"]
        }
      }
    });

    const result = JSON.parse(response.text || '{}');
    return {
      ...result,
      status: 'success',
      language: language
    };
  } catch (error: any) {
    console.error("Gemini Detection Error:", error);
    return {
      status: 'error',
      message: error.message || "Failed to analyze audio sample. Ensure the format is supported."
    };
  }
};
