
import React, { useState } from 'react';
import { Clipboard, Check, AlertCircle } from 'lucide-react';

interface PasteInputProps {
  onPaste: (base64: string, mimeType: string) => void;
  disabled?: boolean;
}

export const PasteInput: React.FC<PasteInputProps> = ({ onPaste, disabled }) => {
  const [value, setValue] = useState('');
  const [isValid, setIsValid] = useState<boolean | null>(null);

  const handleChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const val = e.target.value.trim();
    setValue(val);
    
    if (val.length > 0) {
      let mimeType = 'audio/mpeg'; // Default
      let cleanVal = val;

      // Extract MIME type from Data URI if present
      const dataUriMatch = val.match(/^data:([^;]+);base64,/);
      if (dataUriMatch) {
        mimeType = dataUriMatch[1];
        cleanVal = val.replace(/^data:[^;]+;base64,/, '');
      }

      // Remove any whitespace, newlines, or formatting common in copied Base64
      cleanVal = cleanVal.replace(/\s/g, '');

      // Improved Base64 check
      const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
      const isOk = base64Regex.test(cleanVal);
      
      setIsValid(isOk);
      if (isOk) {
        onPaste(cleanVal, mimeType);
      } else {
        onPaste('', '');
      }
    } else {
      setIsValid(null);
      onPaste('', '');
    }
  };

  return (
    <div className="space-y-4">
      <div className="relative group">
        <textarea
          value={value}
          onChange={handleChange}
          disabled={disabled}
          placeholder="Paste your Base64 encoded audio string here..."
          className={`w-full h-40 bg-slate-950 border-2 p-5 rounded-2xl font-mono text-xs text-blue-400/80 focus:outline-none transition-all resize-none
            ${isValid === true ? 'border-emerald-500/30 group-hover:border-emerald-500/50' : 
              isValid === false ? 'border-red-500/30 group-hover:border-red-500/50' : 
              'border-slate-800 group-hover:border-slate-700'}
            ${disabled ? 'opacity-50 cursor-not-allowed' : ''}`}
        />
        <div className="absolute top-4 right-4 flex items-center gap-2 pointer-events-none">
          {isValid === true && (
            <div className="flex items-center gap-1.5 px-2 py-1 bg-emerald-500/10 text-emerald-400 text-[10px] font-bold rounded border border-emerald-500/20">
              <Check size={10} /> Valid Format
            </div>
          )}
          {isValid === false && (
            <div className="flex items-center gap-1.5 px-2 py-1 bg-red-500/10 text-red-400 text-[10px] font-bold rounded border border-red-500/20">
              <AlertCircle size={10} /> Check Format
            </div>
          )}
          <Clipboard size={16} className="text-slate-600" />
        </div>
      </div>
      
      <p className="text-[10px] text-slate-500 px-2 italic">
        Accepts raw Base64 or Data URIs. Supports any audio format (MP3, WAV, AAC, MP4 etc).
      </p>
    </div>
  );
};
