
import React from 'react';
import { X, Check, Zap, Star, Shield } from 'lucide-react';

interface UpgradeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const UpgradeModal: React.FC<UpgradeModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const plans = [
    {
      name: 'Starter',
      price: '$0',
      description: 'For hobbyists testing the waters.',
      features: ['100 detections/mo', 'Email support', 'API access (limited)', '95% uptime'],
      icon: <Zap className="text-blue-400" />,
      button: 'Current Plan',
      current: true
    },
    {
      name: 'Pro',
      price: '$49',
      description: 'For growing startups and researchers.',
      features: ['5,000 detections/mo', 'Priority support', 'Full API throughput', '99.9% uptime', 'Custom webhooks'],
      icon: <Star className="text-purple-400" />,
      button: 'Upgrade to Pro',
      current: false,
      popular: true
    },
    {
      name: 'Enterprise',
      price: 'Custom',
      description: 'Full-scale verification for giants.',
      features: ['Unlimited detections', 'Dedicated account manager', 'On-premise options', 'Advanced audit logs', 'SLA guarantees'],
      icon: <Shield className="text-emerald-400" />,
      button: 'Contact Sales',
      current: false
    }
  ];

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      <div 
        className="absolute inset-0 bg-slate-950/80 backdrop-blur-sm"
        onClick={onClose}
      />
      <div className="relative w-full max-w-5xl bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200">
        <div className="p-8 border-b border-slate-800 flex justify-between items-center bg-slate-900/50">
          <div>
            <h2 className="text-3xl font-black text-white tracking-tight">Scale Your Voice Verification</h2>
            <p className="text-slate-400 mt-1">Select the plan that fits your detection needs.</p>
          </div>
          <button 
            onClick={onClose}
            className="p-2 hover:bg-slate-800 rounded-full text-slate-400 hover:text-white transition-colors"
          >
            <X size={24} />
          </button>
        </div>

        <div className="p-8 grid grid-cols-1 md:grid-cols-3 gap-6">
          {plans.map((plan) => (
            <div 
              key={plan.name}
              className={`relative flex flex-col p-6 rounded-2xl border-2 transition-all ${
                plan.popular ? 'bg-slate-800/40 border-blue-500/50' : 'bg-slate-950/50 border-slate-800'
              }`}
            >
              {plan.popular && (
                <span className="absolute -top-3 left-1/2 -translate-x-1/2 bg-blue-600 text-white text-[10px] font-black uppercase px-3 py-1 rounded-full tracking-widest">
                  Most Popular
                </span>
              )}
              
              <div className="mb-6 flex items-center justify-between">
                <div className="p-3 bg-slate-900 rounded-xl border border-slate-800">
                  {plan.icon}
                </div>
                <div className="text-right">
                  <span className="text-2xl font-black text-white">{plan.price}</span>
                  {plan.price !== 'Custom' && <span className="text-slate-500 text-sm">/mo</span>}
                </div>
              </div>

              <h3 className="text-xl font-bold text-white mb-2">{plan.name}</h3>
              <p className="text-slate-400 text-sm mb-6 leading-relaxed">{plan.description}</p>

              <ul className="space-y-3 mb-8 flex-1">
                {plan.features.map((feature) => (
                  <li key={feature} className="flex items-start gap-3 text-sm text-slate-300">
                    <Check size={16} className="text-emerald-500 shrink-0 mt-0.5" />
                    {feature}
                  </li>
                ))}
              </ul>

              <button 
                className={`w-full py-3 rounded-xl font-bold transition-all ${
                  plan.current 
                  ? 'bg-slate-800 text-slate-500 cursor-default' 
                  : 'bg-blue-600 hover:bg-blue-500 text-white shadow-lg shadow-blue-900/20'
                }`}
                onClick={plan.current ? undefined : onClose}
              >
                {plan.button}
              </button>
            </div>
          ))}
        </div>

        <div className="p-6 bg-slate-950/50 border-t border-slate-800 text-center">
          <p className="text-slate-500 text-xs">
            Prices are in USD. Billed monthly. 
            <a href="https://ai.google.dev/gemini-api/docs/billing" className="text-blue-400 hover:underline ml-1">Learn about Gemini API billing</a>.
          </p>
        </div>
      </div>
    </div>
  );
};
