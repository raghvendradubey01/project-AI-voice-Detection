
import React from 'react';
import { Copy, Terminal, Server, Shield } from 'lucide-react';

export const Documentation: React.FC = () => {
  const curlExample = `curl -X POST https://voiceverify.ai/api/voice-detection \\
-H "Content-Type: application/json" \\
-H "x-api-key: sk_test_123456789" \\
-d '{
  "language": "Tamil",
  "audioFormat": "mp3",
  "audioBase64": "SUQzBAAAAAAAI1..."
}'`;

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  return (
    <div className="space-y-8 pb-20">
      <section>
        <div className="flex items-center gap-3 mb-6">
          <div className="bg-blue-500/20 p-2 rounded-lg text-blue-400">
            <Server size={24} />
          </div>
          <h2 className="text-2xl font-bold">API Reference</h2>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl overflow-hidden">
          <div className="p-6 border-b border-slate-800">
            <div className="flex items-center gap-2 mb-1">
              <span className="bg-green-500/20 text-green-400 text-[10px] font-black px-2 py-0.5 rounded uppercase tracking-tighter">POST</span>
              <span className="text-slate-400 font-mono text-sm">/api/voice-detection</span>
            </div>
            <p className="text-slate-400 text-sm mt-3">Analyzes a Base64 encoded audio sample and returns the classification as AI or Human.</p>
          </div>

          <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <h3 className="text-slate-300 font-bold mb-4 flex items-center gap-2">
                <Shield size={16} className="text-blue-400" />
                Authentication
              </h3>
              <p className="text-sm text-slate-400 mb-4">Requests must include an API Key in the headers.</p>
              <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 font-mono text-xs">
                <div className="text-blue-400">x-api-key: <span className="text-slate-300">YOUR_SECRET_API_KEY</span></div>
              </div>
            </div>

            <div>
              <h3 className="text-slate-300 font-bold mb-4 flex items-center gap-2">
                <Terminal size={16} className="text-purple-400" />
                Input Constraints
              </h3>
              <ul className="text-xs text-slate-400 space-y-2">
                <li className="flex justify-between border-b border-slate-800/50 pb-1">
                  <span>Supported Languages</span>
                  <span className="text-slate-300">Tamil, English, Hindi, Malayalam, Telugu</span>
                </li>
                <li className="flex justify-between border-b border-slate-800/50 pb-1">
                  <span>Audio Format</span>
                  <span className="text-slate-300">Universal (MP3, WAV, M4A, AAC)</span>
                </li>
                <li className="flex justify-between border-b border-slate-800/50 pb-1">
                  <span>Encoding</span>
                  <span className="text-slate-300">Base64 String</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-slate-200 font-bold">Usage Example (cURL)</h3>
          <button 
            onClick={() => copyToClipboard(curlExample)}
            className="text-slate-500 hover:text-white flex items-center gap-2 text-xs transition-colors"
          >
            <Copy size={14} />
            Copy Code
          </button>
        </div>
        <div className="bg-slate-950 rounded-xl p-5 border border-slate-800 overflow-x-auto">
          <pre className="mono text-xs text-blue-400/90 leading-relaxed">
            {curlExample}
          </pre>
        </div>
      </section>

      <section>
        <h3 className="text-slate-200 font-bold mb-4">Standard Response Body</h3>
        <div className="bg-slate-950 rounded-xl p-5 border border-slate-800 overflow-x-auto">
          <pre className="mono text-xs text-emerald-400 leading-relaxed">
{`{
  "status": "success",
  "language": "Tamil",
  "classification": "AI_GENERATED",
  "confidenceScore": 0.91,
  "explanation": "Unnatural pitch consistency and robotic speech patterns detected"
}`}
          </pre>
        </div>
      </section>
    </div>
  );
};
