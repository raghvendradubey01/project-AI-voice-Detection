
import React, { useRef, useState } from 'react';
import { Upload, FileAudio, X, AlertCircle } from 'lucide-react';

interface FileUploadProps {
  onFileSelect: (base64: string, name: string, mimeType: string) => void;
  disabled?: boolean;
}

export const FileUpload: React.FC<FileUploadProps> = ({ onFileSelect, disabled }) => {
  const [dragActive, setDragActive] = useState(false);
  const [fileName, setFileName] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFile = async (file: File) => {
    // Relaxed type checking to allow any audio/video containers commonly used for voice
    if (!file.type.startsWith('audio/') && !file.type.startsWith('video/mp4')) {
      setError("Please upload a valid audio file (MP3, WAV, M4A, etc.).");
      return;
    }
    
    setError(null);
    setFileName(file.name);

    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      const base64 = result.split(',')[1];
      onFileSelect(base64, file.name, file.type || 'audio/mpeg');
    };
    reader.readAsDataURL(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragActive(false);
    if (disabled) return;
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFile(e.target.files[0]);
    }
  };

  const reset = () => {
    setFileName(null);
    setError(null);
    if (inputRef.current) inputRef.current.value = '';
    onFileSelect('', '', '');
  };

  return (
    <div className="w-full">
      {!fileName ? (
        <div
          onDragOver={(e) => { e.preventDefault(); setDragActive(true); }}
          onDragLeave={() => setDragActive(false)}
          onDrop={handleDrop}
          className={`relative border-2 border-dashed rounded-xl p-8 transition-all flex flex-col items-center justify-center cursor-pointer
            ${dragActive ? 'border-blue-500 bg-blue-500/10' : 'border-slate-700 hover:border-slate-500 bg-slate-800/50'}
            ${disabled ? 'opacity-50 cursor-not-allowed' : ''}`}
          onClick={() => !disabled && inputRef.current?.click()}
        >
          <input
            ref={inputRef}
            type="file"
            accept="audio/*,video/mp4"
            className="hidden"
            onChange={handleChange}
            disabled={disabled}
          />
          <Upload className={`w-12 h-12 mb-4 ${dragActive ? 'text-blue-400' : 'text-slate-500'}`} />
          <p className="text-slate-300 font-medium mb-1">Click or drag audio here</p>
          <p className="text-slate-500 text-sm italic">Supports MP3, WAV, M4A, AAC, etc.</p>
          
          {error && (
            <div className="mt-4 flex items-center gap-2 text-red-400 text-sm bg-red-400/10 px-3 py-1.5 rounded-lg">
              <AlertCircle size={14} />
              {error}
            </div>
          )}
        </div>
      ) : (
        <div className="flex items-center justify-between p-4 bg-slate-800 border border-slate-700 rounded-xl">
          <div className="flex items-center gap-3 overflow-hidden">
            <div className="bg-blue-500/20 p-2 rounded-lg text-blue-400">
              <FileAudio size={24} />
            </div>
            <div className="flex flex-col overflow-hidden">
              <span className="text-slate-200 font-medium truncate">{fileName}</span>
              <span className="text-slate-500 text-xs">Dynamic Analysis Mode</span>
            </div>
          </div>
          <button 
            onClick={reset}
            className="text-slate-400 hover:text-white transition-colors p-2"
            disabled={disabled}
          >
            <X size={20} />
          </button>
        </div>
      )}
    </div>
  );
};
