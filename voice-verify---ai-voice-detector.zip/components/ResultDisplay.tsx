
import React from 'react';
import { DetectionResponse } from '../types';
import { ShieldCheck, ShieldAlert, Zap, Info, Terminal } from 'lucide-react';
import { PieChart, Pie, Cell, ResponsiveContainer } from 'recharts';

interface ResultDisplayProps {
  result: DetectionResponse;
}

export const ResultDisplay: React.FC<ResultDisplayProps> = ({ result }) => {
  if (result.status === 'error') {
    return (
      <div className="bg-red-500/10 border border-red-500/30 p-6 rounded-xl flex items-start gap-4 animate-in fade-in slide-in-from-top-4 duration-500">
        <ShieldAlert className="text-red-500 shrink-0 mt-1" />
        <div>
          <h3 className="text-red-400 font-bold text-lg mb-1">Detection Error</h3>
          <p className="text-red-300/80">{result.message}</p>
        </div>
      </div>
    );
  }

  const isAI = result.classification === 'AI_GENERATED';
  const confidencePercent = Math.round((result.confidenceScore || 0) * 100);
  
  const chartData = [
    { name: 'Confidence', value: result.confidenceScore || 0 },
    { name: 'Remaining', value: 1 - (result.confidenceScore || 0) }
  ];

  const CHART_COLORS = isAI ? ['#f43f5e', '#1e293b'] : ['#10b981', '#1e293b'];

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-top-8 duration-700">
      <div className={`p-8 rounded-2xl border-2 overflow-hidden relative ${isAI ? 'bg-rose-500/5 border-rose-500/30' : 'bg-emerald-500/5 border-emerald-500/30'}`}>
        <div className="flex flex-col md:flex-row items-center gap-8 relative z-10">
          <div className="w-40 h-40 shrink-0 relative">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={chartData}
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={75}
                  startAngle={90}
                  endAngle={450}
                  dataKey="value"
                  stroke="none"
                >
                  {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={CHART_COLORS[index]} />
                  ))}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
            <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
              <span className="text-2xl font-bold">{confidencePercent}%</span>
              <span className="text-[10px] text-slate-500 uppercase tracking-widest font-bold">Certainty</span>
            </div>
          </div>

          <div className="flex-1 text-center md:text-left">
            <div className="flex items-center justify-center md:justify-start gap-2 mb-2">
              <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase tracking-widest ${isAI ? 'bg-rose-500/20 text-rose-400' : 'bg-emerald-500/20 text-emerald-400'}`}>
                Classification
              </span>
              <span className="px-3 py-1 rounded-full text-xs font-bold bg-slate-800 text-slate-400 uppercase tracking-widest">
                {result.language}
              </span>
            </div>
            
            <h2 className={`text-4xl md:text-5xl font-black mb-4 tracking-tighter ${isAI ? 'text-rose-500' : 'text-emerald-500'}`}>
              {isAI ? 'AI GENERATED' : 'HUMAN SPEECH'}
            </h2>
            
            <p className="text-slate-300 leading-relaxed max-w-xl">
              <Info className="inline-block mr-2 text-slate-500" size={18} />
              {result.explanation}
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-slate-900/50 border border-slate-800 p-5 rounded-xl">
          <div className="flex items-center gap-2 mb-4 text-blue-400">
            <Zap size={18} />
            <h3 className="font-bold uppercase tracking-wider text-sm">Technical Indicators</h3>
          </div>
          <ul className="space-y-3">
            {[
              { label: 'Harmonic Analysis', value: isAI ? 'Synthetic' : 'Organic' },
              { label: 'Pitch Variance', value: isAI ? 'Static' : 'Dynamic' },
              { label: 'Temporal Consistency', value: isAI ? 'Fixed' : 'Variable' }
            ].map((item, i) => (
              <li key={i} className="flex justify-between items-center text-sm border-b border-slate-800 pb-2">
                <span className="text-slate-400">{item.label}</span>
                <span className={`font-mono ${isAI ? 'text-rose-400' : 'text-emerald-400'}`}>{item.value}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="bg-slate-900/50 border border-slate-800 p-5 rounded-xl">
          <div className="flex items-center gap-2 mb-4 text-purple-400">
            <Terminal size={18} />
            <h3 className="font-bold uppercase tracking-wider text-sm">Response Payload</h3>
          </div>
          <pre className="text-[11px] mono text-slate-500 overflow-x-auto bg-slate-950 p-3 rounded-lg border border-slate-800/50">
            {JSON.stringify(result, null, 2)}
          </pre>
        </div>
      </div>
    </div>
  );
};
